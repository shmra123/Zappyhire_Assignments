import random

def generate_random_decimal(start, end):
    random_decimal = random.uniform(start, end)
    return random_decimal

def main():
    start = float(input("Input the start of the range: "))
    end = float(input("Input the end of the range: "))

    random_decimal = generate_random_decimal(start, end)
    print("Random decimal number:", random_decimal)

if __name__ == "__main__":
    main()
