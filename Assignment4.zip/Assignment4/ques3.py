a = [1, 2, 3, 4]
try:
    i = int(input("Input the index: "))
    print("Value at index:", a[i])
except IndexError:
    print("Please input a valid index.")
