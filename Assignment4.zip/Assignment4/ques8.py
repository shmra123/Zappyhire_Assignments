import os
def main():
    cwd = os.getcwd()
    print("Current working directory:", cwd)
if __name__ == "__main__":
    main()
