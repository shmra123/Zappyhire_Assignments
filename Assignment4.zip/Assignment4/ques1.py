try:
    a = float(input("Input the first number: "))
    b = float(input("Input the second number: "))
    c = a + b
    print("Sum result:", c)
except ValueError:
    print("Please input a numerical value.")
