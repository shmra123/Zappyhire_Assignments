def new_file():
    file_name = "new_file.txt"
    with open(file_name, 'w') as file:
        file.write("Hello, this is a new text file created using the open() function.")
    print(f"File '{file_name}' has been created successfully.")

new_file()
