def read_file():
    try:
        with open("po.txt", "r") as file:
            for line in file:
                print(line.strip())
    except FileNotFoundError:
        print("Error: 'poem.txt' file not found.")

read_file()
