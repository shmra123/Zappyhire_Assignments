try:
    read_file = open("hello.txt")
    print(read_file.read())
except FileNotFoundError:
    print("File Not Found")



